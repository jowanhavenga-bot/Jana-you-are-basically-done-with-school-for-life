# Gift website (single file)
Everything (images, fonts, code) is inside `index.html`. Nothing else is needed.

1. On github.com create a new Public repository.
2. Click **uploading an existing file**, drag in `index.html` only, and click **Commit changes**.
3. Go to **Settings > Pages**, choose branch `main` and folder `/ (root)`, then **Save**.
4. After a minute or two your link appears at the top of that page.
